const $=id=>document.getElementById(id);
const today=()=>new Date().toISOString().slice(0,10);
const defaults={
 targets:{calories:2700,protein:160},
 diet:[
  {time:"07:00",name:"Pequeno-almoço",icon:"🍳",desc:"3 ovos, 80 g de pão integral e 1 banana",cal:550,protein:30},
  {time:"12:00",name:"Almoço",icon:"🍗",desc:"180 g de frango, 100 g de arroz cru, 200 g de legumes e 1 colher de azeite",cal:850,protein:58},
  {time:"16:00",name:"Lanche",icon:"🥣",desc:"200 g de Skyr, 40 g de aveia, 1 maçã e 15 g de amendoins",cal:400,protein:28},
  {time:"20:00",name:"Jantar",icon:"🐟",desc:"120 g de atum escorrido, 300 g de batata, 2 ovos, salada e 1 iogurte natural",cal:650,protein:50}
 ],
 shopping:["Ovos – 24 unidades","Frango – 1,5 kg","Atum ou sardinhas – 5 latas","Arroz – 1 kg","Batatas – 2 kg","Aveia – 500 g","Skyr ou fromage blanc – 1,5 kg","Legumes congelados – 2 kg","Bananas e maçãs – 14 unidades","Lentilhas – 500 g"],
 workouts:[["Agachamentos","3 × 12 repetições"],["Flexões (adaptadas se necessário)","3 × 8 repetições"],["Prancha","3 × 20–30 segundos"],["Remada com mochila","3 × 12 repetições"]]
};
let state=JSON.parse(localStorage.getItem("myDietState")||"null")||{targets:defaults.targets,meals:{},weights:[],shopping:defaults.shopping.map(x=>({name:x,done:false})),photos:[]};
function save(){localStorage.setItem("myDietState",JSON.stringify(state));render()}
function dayMeals(){return state.meals[today()]||[]}
function render(){
 const meals=dayMeals(),cal=meals.reduce((a,x)=>a+x.cal,0),pro=meals.reduce((a,x)=>a+x.pro,0);
 $("calories").textContent=cal;$("protein").textContent=pro;$("calTarget").textContent=state.targets.calories;$("proteinTarget").textContent=state.targets.protein;
 $("calBar").style.width=Math.min(100,cal/state.targets.calories*100)+"%";$("proteinBar").style.width=Math.min(100,pro/state.targets.protein*100)+"%";
 $("mealList").innerHTML=meals.length?meals.map((m,i)=>`<div class="entry"><div><b>${esc(m.name)}</b><br><small>${esc(m.type)}</small></div><div>${m.cal} kcal · ${m.pro} g <button class="text-btn" onclick="removeMeal(${i})">×</button></div></div>`).join(""):'Ainda não registaste refeições.';
 $("dietCards").innerHTML=defaults.diet.map(m=>`<div class="meal-card"><div class="meal-icon">${m.icon}</div><div><small>${m.time}</small><h3>${m.name}</h3><p>${m.desc}</p><b>~${m.cal} kcal · ${m.pro} g proteína</b></div></div>`).join("");
 $("targetCalories").value=state.targets.calories;$("targetProtein").value=state.targets.protein;
 $("weightHistory").innerHTML=state.weights.length?[...state.weights].reverse().map(w=>`<div class="entry"><div><b>${w.weight} kg</b><br><small>${w.date}${w.waist?` · cintura ${w.waist} cm`:""}</small></div></div>`).join(""):'Ainda não existem medições.';
 $("currentWeight").textContent=state.weights.length?Number(state.weights[state.weights.length-1].weight).toFixed(1).replace(".",","):"90,0";
 $("shoppingList").innerHTML=state.shopping.map((x,i)=>`<label class="shopping-item ${x.done?"done":""}"><input type="checkbox" ${x.done?"checked":""} onchange="toggleShopping(${i},this.checked)"><span>${esc(x.name)}</span></label>`).join("");
 $("workoutList").innerHTML=defaults.workouts.map(x=>`<div class="exercise"><b>${x[0]}</b><small>${x[1]}</small></div>`).join("");
 $("photos").innerHTML=(state.photos||[]).map((src,i)=>`<img src="${src}" alt="Fotografia de evolução ${i+1}">`).join("");
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
window.removeMeal=i=>{state.meals[today()].splice(i,1);save()};
window.toggleShopping=(i,v)=>{state.shopping[i].done=v;save()};
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".tab,.page").forEach(x=>x.classList.remove("active"));b.classList.add("active");$(b.dataset.page).classList.add("active")}));
$("addMeal").onclick=()=>{let cal=+$("mealCalories").value,pro=+$("mealProtein").value,name=$("mealName").value.trim();if(!name||cal<0||pro<0||!$("mealCalories").value||!$("mealProtein").value){alert("Preenche a descrição, calorias e proteína.");return}state.meals[today()]??=[];state.meals[today()].push({name,cal,pro,type:$("mealType").value});$("mealName").value=$("mealCalories").value=$("mealProtein").value="";save()};
$("clearMeals").onclick=()=>{if(confirm("Queres apagar os registos de hoje?")){state.meals[today()]=[];save()}};
$("saveTargets").onclick=()=>{let c=+$("targetCalories").value,p=+$("targetProtein").value;if(c<1200||p<50){alert("Introduz objetivos válidos.");return}state.targets={calories:c,protein:p};save();alert("Objetivos guardados.")};
$("addWeight").onclick=()=>{let w=+$("weightInput").value,waist=$("waistInput").value;if(w<35||w>300){alert("Confirma o peso introduzido.");return}state.weights.push({weight:w,waist:waist?Number(waist):null,date:today()});$("weightInput").value=$("waistInput").value="";save()};
$("photoInput").onchange=async e=>{for(const f of e.target.files){if(!f.type.startsWith("image/"))continue;const data=await new Promise((res,rej)=>{let r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(f)});state.photos.push(data)}try{save()}catch(err){alert("O armazenamento do telemóvel ficou cheio. Experimenta adicionar menos fotografias ou imagens mais pequenas.")}e.target.value=""};
$("resetShopping").onclick=()=>{state.shopping=defaults.shopping.map(x=>({name:x,done:false}));save()};
$("recalculate").onclick=()=>{if(state.weights.length<3){$("adjustment").textContent="Regista pelo menos 3 medições em dias diferentes antes de rever o objetivo. Com poucas medições, não é seguro ajustar as calorias.";return}let a=state.weights[0],b=state.weights[state.weights.length-1],days=(new Date(b.date)-new Date(a.date))/86400000,loss=Number(a.weight)-Number(b.weight);if(days<7){$("adjustment").textContent="Continua a registar durante pelo menos 7 dias. Vamos comparar médias semanais para evitar ajustes por flutuações normais.";return}let rate=loss/(days/7);if(rate>0.7){$("adjustment").textContent="A perda registada está acima de 0,7 kg/semana. Considera aumentar cerca de 150–200 kcal/dia, sobretudo se sentires cansaço. Confirma a tendência com mais medições."}else if(rate<0.15){$("adjustment").textContent="A perda está lenta ou estável. Se cumpriste o plano durante 2–3 semanas, podes considerar reduzir apenas 100–150 kcal/dia. Não faças cortes agressivos."}else{$("adjustment").textContent="A evolução está dentro de uma faixa gradual. Mantém os objetivos atuais e continua a acompanhar a energia e a força."}};
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
render();