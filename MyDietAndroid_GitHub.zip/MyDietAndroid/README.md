# My Diet Android
Projeto Android híbrido (interface web offline dentro de uma aplicação Android).
## Gerar APK
O GitHub Actions compila automaticamente ao enviar para `main`, ou manualmente em Actions > Build My Diet APK > Run workflow. No fim, abrir a execução e descarregar o artefacto `MyDiet-APK`.
O APK de depuração não é publicado na Play Store. Os dados ficam guardados localmente no dispositivo; desinstalar ou limpar os dados pode apagá-los.
