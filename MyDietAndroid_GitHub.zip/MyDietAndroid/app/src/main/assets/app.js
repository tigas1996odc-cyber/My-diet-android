const $=id=>document.getElementById(id), get=(k,d)=>JSON.parse(localStorage.getItem(k)||JSON.stringify(d)), put=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{document.querySelectorAll('section').forEach(s=>s.classList.remove('active'));$(b.dataset.tab).classList.add('active')});
let weights=get('weights',[]), foods=get('foods',[]), items=get('items',['Ovos','Frango','Atum ou sardinhas','Arroz','Batatas','Aveia','Skyr / fromage blanc','Legumes congelados','Bananas','Maçãs','Lentilhas']);
function renderWeights(){$('weightList').innerHTML=weights.slice().reverse().map(x=>`<li>${x.date}: <b>${x.value} kg</b></li>`).join('')}
function renderFoods(){
 $('foodList').innerHTML=foods.map((x,i)=>`<li>${escapeHtml(x.name)}: ${x.kcal} kcal, ${x.protein} g proteína, ${x.carbs??'—'} g hidratos, ${x.fat??'—'} g gorduras <button onclick="removeFood(${i})">×</button></li>`).join('');
 for(const [id,key,unit] of [['totalKcal','kcal',''],['totalProtein','protein',' g'],['totalCarbs','carbs',' g'],['totalFat','fat',' g']]){
 let known=foods.filter(x=>x[key]!=null); $(''+id).textContent=known.reduce((a,x)=>a+Number(x[key]),0).toFixed(1)+unit+(known.length<foods.length?'*':''); }
}
window.removeFood=i=>{foods.splice(i,1);put('foods',foods);renderFoods()};
$('saveWeight').onclick=()=>{let v=parseFloat($('weight').value);if(v>0){weights.push({value:v,date:new Date().toLocaleDateString('pt-PT')});put('weights',weights);$('weight').value='';renderWeights()}};
$('addFood').onclick=()=>{let name=$('food').value,kcal=Number($('kcal').value),protein=Number($('protein').value);if(name&&kcal>=0&&protein>=0&&Number($('carbs').value)>=0&&Number($('fat').value)>=0){foods.push({name,kcal,protein,carbs:$('carbs').value===''?null:Number($('carbs').value),fat:$('fat').value===''?null:Number($('fat').value)});put('foods',foods);renderFoods();$('food').value=$('kcal').value=$('protein').value=''}};
function renderItems(){$('shopping').innerHTML=items.map((x,i)=>`<label><input type="checkbox"> ${x} <button onclick="deleteItem(${i})">×</button></label>`).join('')}
window.deleteItem=i=>{items.splice(i,1);put('items',items);renderItems()};
$('addItem').onclick=()=>{let x=$('newItem').value.trim();if(x){items.push(x);put('items',items);$('newItem').value='';renderItems()}};
$('photo').onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{let photos=get('photos',[]);photos.push(r.result);put('photos',photos);renderPhotos()};r.readAsDataURL(f)};
function renderPhotos(){$('gallery').innerHTML=get('photos',[]).map(src=>`<img src="${src}" alt="Foto de evolução">`).join('')}
renderWeights();renderFoods();renderItems();renderPhotos();

function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
$('server').value=get('aiServer','');
function serverUrl(){let u=new URL($('server').value.trim());if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.pathname!=='/'||u.search||u.hash)throw Error('Introduz apenas o endereço do servidor e a porta.');return u.origin;}
$('saveServer').onclick=()=>{try{put('aiServer',serverUrl());$('aiStatus').textContent='Endereço guardado.'}catch(e){$('aiStatus').textContent=e.message}};
let aiRows=[];
function entryFor(r){
 let f=r.options[Number(r.select.value)],g=Number(r.grams.value);
 if(r.select.value===''||!f||!Number.isFinite(g)||g<=0)return null;
 let calc=k=>f[k]==null||!Number.isFinite(Number(f[k]))?null:Math.round(Number(f[k])*g/10)/10;
 return {name:f.nome+' ('+g+' g)',kcal:calc('kcal_100g'),protein:calc('proteinas_100g'),carbs:calc('hidratos_100g'),fat:calc('gorduras_100g')};
}
function selectedAI(){return aiRows.map(entryFor).filter(x=>x&&x.kcal!=null&&x.protein!=null)}
function summary(x){return `${x.kcal??'—'} kcal | ${x.protein??'—'} g proteínas | ${x.carbs??'—'} g hidratos | ${x.fat??'—'} g gorduras`}
function aiTotal(){
 for(const r of aiRows){let x=entryFor(r);r.preview.textContent=x?summary(x):'Seleciona um alimento e um peso válido.';r.add.disabled=!x||x.kcal==null||x.protein==null;}
 let x=selectedAI();let total={};for(const k of ['kcal','protein','carbs','fat'])total[k]=x.some(v=>v[k]==null)?null:Math.round(x.reduce((a,v)=>a+v[k],0)*10)/10;
 $('aiTotals').textContent=x.length?'Total selecionado: '+summary(total):'';$('saveAI').hidden=false;$('saveAI').disabled=!x.length;
}
function addSuggestion(s){
 let div=document.createElement('div');div.className='airow';let label=document.createElement('b');label.textContent=s.identificado;
 let select=document.createElement('select'),options=s.opcoes_insa||[];
 function fill(){select.replaceChildren(new Option('Escolher alimento / ignorar',''));options.forEach((f,i)=>select.add(new Option(f.nome,String(i))));}
 fill();let grams=document.createElement('input');grams.type='number';grams.min='1';grams.step='any';grams.value=s.gramas_sugeridas||100;
 let search=document.createElement('input');search.placeholder='Pesquisar alternativa';let btn=document.createElement('button');btn.textContent='Pesquisar';
 let preview=document.createElement('p');preview.className='nutritionPreview';let add=document.createElement('button');add.textContent='Adicionar ao contador';
 let r={select,grams,options,preview,add};
 btn.onclick=async()=>{try{let res=await fetch(serverUrl()+'/foods/search?q='+encodeURIComponent(search.value));if(!res.ok)throw Error('Pesquisa falhou');let data=await res.json();options.splice(0,options.length,...data.results);fill();$('aiStatus').textContent=options.length?'Escolhe o alimento correto.':'Nenhum resultado. Tenta outro termo.';aiTotal();}catch(e){$('aiStatus').textContent=e.message}};
 add.onclick=()=>{let x=entryFor(r);if(!x||x.kcal==null||x.protein==null)return;foods.push(x);put('foods',foods);renderFoods();aiRows=aiRows.filter(v=>v!==r);div.remove();aiTotal();$('aiStatus').textContent='Alimento adicionado ao contador.';};
 select.onchange=grams.oninput=aiTotal;div.append(label,select,document.createTextNode('Peso comestível (g)'),grams,preview,add,search,btn);$('suggestions').append(div);aiRows.push(r);aiTotal();
}
$('analyze').onclick=async()=>{let f=$('mealPhoto').files[0];if(!f){$('aiStatus').textContent='Escolhe uma fotografia.';return}if(f.size>10*1024*1024){$('aiStatus').textContent='Imagem superior a 10 MB.';return} $('analyze').disabled=true;aiRows=[];$('suggestions').replaceChildren();aiTotal();$('aiStatus').textContent='A analisar... pode demorar alguns minutos.';try{let form=new FormData();form.append('photo',f);let res=await fetch(serverUrl()+'/analyze-meal',{method:'POST',body:form});if(!res.ok)throw Error('Erro do servidor: '+res.status);let data=await res.json();if(!data.success)throw Error('Análise falhou');(data.suggestions||[]).forEach(addSuggestion);$('aiStatus').textContent=aiRows.length?'Confirma as sugestões abaixo.':'Sem sugestões. Usa o registo manual.';}catch(e){$('aiStatus').textContent='Não foi possível analisar: '+e.message+' Verifica o servidor e a rede Wi-Fi.'}finally{$('analyze').disabled=false}};
$('saveAI').onclick=()=>{let entries=selectedAI();if(!entries.length)return;foods.push(...entries);put('foods',foods);renderFoods();aiRows=[];$('suggestions').replaceChildren();aiTotal();$('aiStatus').textContent='Alimentos guardados no contador.'};
