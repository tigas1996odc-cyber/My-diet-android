const $=id=>document.getElementById(id), get=(k,d)=>JSON.parse(localStorage.getItem(k)||JSON.stringify(d)), put=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{document.querySelectorAll('section').forEach(s=>s.classList.remove('active'));$(b.dataset.tab).classList.add('active')});
let weights=get('weights',[]), foods=get('foods',[]), items=get('items',['Ovos','Frango','Atum ou sardinhas','Arroz','Batatas','Aveia','Skyr / fromage blanc','Legumes congelados','Bananas','Maçãs','Lentilhas']);
function renderWeights(){$('weightList').innerHTML=weights.slice().reverse().map(x=>`<li>${x.date}: <b>${x.value} kg</b></li>`).join('')}
function renderFoods(){$('foodList').innerHTML=foods.map((x,i)=>`<li>${x.name}: ${x.kcal} kcal, ${x.protein} g proteína <button onclick="removeFood(${i})">×</button></li>`).join('');$('totalKcal').textContent=foods.reduce((a,x)=>a+x.kcal,0);$('totalProtein').textContent=foods.reduce((a,x)=>a+x.protein,0)+' g'}
window.removeFood=i=>{foods.splice(i,1);put('foods',foods);renderFoods()};
$('saveWeight').onclick=()=>{let v=parseFloat($('weight').value);if(v>0){weights.push({value:v,date:new Date().toLocaleDateString('pt-PT')});put('weights',weights);$('weight').value='';renderWeights()}};
$('addFood').onclick=()=>{let name=$('food').value,kcal=Number($('kcal').value),protein=Number($('protein').value);if(name&&kcal>=0&&protein>=0){foods.push({name,kcal,protein});put('foods',foods);renderFoods();$('food').value=$('kcal').value=$('protein').value=''}};
function renderItems(){$('shopping').innerHTML=items.map((x,i)=>`<label><input type="checkbox"> ${x} <button onclick="deleteItem(${i})">×</button></label>`).join('')}
window.deleteItem=i=>{items.splice(i,1);put('items',items);renderItems()};
$('addItem').onclick=()=>{let x=$('newItem').value.trim();if(x){items.push(x);put('items',items);$('newItem').value='';renderItems()}};
$('photo').onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{let photos=get('photos',[]);photos.push(r.result);put('photos',photos);renderPhotos()};r.readAsDataURL(f)};
function renderPhotos(){$('gallery').innerHTML=get('photos',[]).map(src=>`<img src="${src}" alt="Foto de evolução">`).join('')}
renderWeights();renderFoods();renderItems();renderPhotos();
